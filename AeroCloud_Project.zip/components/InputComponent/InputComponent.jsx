import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  TextInput,
  View,
  TouchableOpacity,
} from "react-native";
import { FontAwesome } from "@expo/vector-icons";
import { Colors } from "../../constants/Colors";
import { useColorScheme } from "../../hooks/useColorScheme";
import { ThemedText } from "../ThemedText";

const InputComponent = ({
  label,
  placeholder,
  value,
  onChangeText,
  onSubmitEditing,
}) => {
  const [isPasswordVisible, setIsPasswordVisible] = useState(
    label.toLowerCase() === "password" ||
      label.toLowerCase().includes("password")
  );
  const [isFocused, setIsFocused] = useState(false);
  const ColorScheme = useColorScheme();

  const togglePasswordVisibility = () => {
    setIsPasswordVisible(!isPasswordVisible);
  };

  const handleFocus = () => {
    setIsFocused(true);
  };

  const handleBlur = () => {
    setIsFocused(false);
  };

  return (
    <View
      style={[
        styles.inputContainer,
        { borderColor: Colors[ColorScheme ?? "light"].authBorder },
      ]}
    >
      <ThemedText
        style={[
          styles.label,
          { backgroundColor: Colors[ColorScheme ?? "light"].background },
        ]}
      >
        {label}
      </ThemedText>
      <View
        style={[
          styles.inputWrapper,
          { borderColor: Colors[ColorScheme ?? "light"].inputBorder },
        ]}
      >
        <TextInput
          style={[styles.input, { color: Colors[ColorScheme ?? "light"].text }]}
          placeholder={placeholder}
          value={value}
          onChangeText={onChangeText}
          onSubmitEditing={onSubmitEditing}
          secureTextEntry={
            label.toLowerCase().includes("password") && isPasswordVisible
          }
          onFocus={handleFocus}
          onBlur={handleBlur}
          placeholderTextColor={Colors[ColorScheme ?? "light"].placeholderColor}
        />
        {label.toLowerCase().includes("password") && (
          <TouchableOpacity
            onPress={togglePasswordVisibility}
            style={styles.icon}
          >
            <FontAwesome
              name={isPasswordVisible ? "eye-slash" : "eye"}
              size={20}
            />
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
};

export default InputComponent;

const styles = StyleSheet.create({
  inputContainer: {
    marginBottom: 15,
    marginTop: 20,
    borderWidth: 1,
    borderRadius: 15,
  },
  label: {
    position: "absolute",
    top: -10,
    left: 15,
    paddingHorizontal: 5,
    fontSize: 16,
    zIndex: 1,
  },
  inputWrapper: {
    borderRadius: 10,
    marginBottom: 5,
    zIndex: 0,
    flexDirection: "row",
    alignItems: "center",
    padding: 6,
  },
  input: {
    flex: 1,
    height: 50,
    paddingHorizontal: 10,
    borderWidth: 0,
  },
  icon: {
    padding: 10,
  },
});
