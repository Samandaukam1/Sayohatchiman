import React, { useState, useCallback } from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  FlatList,
  TouchableOpacity,
} from "react-native";
import { TourPackages } from "../../helpers/mock";
import SVGImages from "../../assets/images/SVGIcons";
import { router } from "expo-router";
import { ThemedText } from "../ThemedText";
import { Colors } from "../../constants/Colors";
import { useColorScheme } from "../../hooks/useColorScheme";
import { LinearGradient } from "expo-linear-gradient";
import { AntDesign } from "@expo/vector-icons";

const HomePackages = () => {
  const colorScheme = useColorScheme();
  // Manage liked state for each item
  const [likedPackages, setLikedPackages] = useState({});

  const handleLike = useCallback((id) => {
    setLikedPackages((prevLikedPackages) => ({
      ...prevLikedPackages,
      [id]: !prevLikedPackages[id], // Toggle like state for specific item
    }));
  }, []);

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.slide}
      onPress={() => router.push(`/tour-packages/${item.id}`)}
    >
      <LinearGradient
        colors={Colors[colorScheme ?? "light"].socialLoginBG}
        style={styles.gradientBackground}
        start={{ x: 0.5, y: 0 }}
        end={{ x: 0.5, y: 1 }}
      >
        <View style={styles.card}>
          <View style={styles.imageContainer}>
            <TouchableOpacity
              style={styles.wishlistBox}
              onPress={() => handleLike(item.id)}
            >
              <AntDesign
                name={likedPackages[item.id] ? "heart" : "hearto"}
                size={20}
                color={likedPackages[item.id] ? "red" : "white"}
              />
            </TouchableOpacity>
            <Image source={item.mainImage} style={styles.mainImage} />
          </View>
          <View style={styles.details}>
            <ThemedText style={styles.name}>
              {item.name.length > 18
                ? `${item.name.substring(0, 18)}...`
                : item.name}
            </ThemedText>
            <View style={styles.starContainer}>
              <SVGImages.StarReview />
              <ThemedText style={styles.reviews}>
                {item.reviews} reviews
              </ThemedText>
            </View>
            <ThemedText style={styles.about}>
              {item.about.length > 40
                ? `${item.about.substring(0, 43)}...`
                : item.about}
            </ThemedText>
          </View>
        </View>
      </LinearGradient>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <ThemedText type="title" style={styles.heading}>
        Exclusive Packages
      </ThemedText>
      <FlatList
        data={TourPackages}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderItem}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 20,
    paddingBottom: 40,
  },
  heading: {
    fontSize: 20,
    marginBottom: 20,
  },
  slide: {
    width: 230, // Fixed width for each slide
    height: 350, // Fixed height for each slide
    marginRight: 20,
  },
  gradientBackground: {
    flex: 1,
    borderRadius: 10,
    overflow: "hidden", // Ensures that the card respects the gradient bounds
    flexDirection: "row",
    justifyContent: "center",
    elevation: 3,
    zIndex: 1,
  },
  card: {
    flex: 1,
    borderRadius: 10,
    overflow: "hidden",
    marginBottom: 30,
  },
  mainImage: {
    width: "100%",
    height: 200,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  details: {
    padding: 15,
  },
  name: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 5,
  },
  reviews: {
    marginBottom: 5,
  },
  about: {
    fontSize: 14,
    marginBottom: 8,
  },
  starContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 5,
    justifyContent: "space-between",
  },
  imageContainer: {
    position: "relative",
  },
  wishlistBox: {
    position: "absolute",
    top: 10,
    right: 10,
    backgroundColor: "#33B2FF",
    zIndex: 1,
    padding: 5,
    borderRadius: 50,
    width: 30,
    height: 30,
    justifyContent: "center",
    alignItems: "center",
  },
});

export default HomePackages;
