import React, { memo } from "react";
import { Image, StyleSheet, Text, View, TouchableOpacity } from "react-native";
import ProfileImg from "../../assets/images/Images/ProfileImage.png";
import NotificationIcon from "../../assets/images/SVGIcons/NotificationIcon";
import { ThemedText } from "../ThemedText";
import { Colors } from "../../constants/Colors";
import { useColorScheme } from "../../hooks/useColorScheme";
import { LinearGradient } from "expo-linear-gradient";

const HomeHeader = () => {
  const colorScheme = useColorScheme(); // Simplified variable name
  const themeColors = Colors[colorScheme ?? "light"]; // Pre-compute theme colors

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.profileContainer}>
        <Image source={ProfileImg} style={styles.profileImage} />
      </TouchableOpacity>
      <View style={styles.greetingContainer}>
        <ThemedText style={styles.greetingText}>Hello!</ThemedText>
        <ThemedText style={styles.userName}>Cameron Williamson</ThemedText>
      </View>
      <LinearGradient
        colors={Colors[colorScheme ?? "light"].socialLoginBG}
        style={styles.iconContainer}
        start={{ x: 0.5, y: 0 }}
        end={{ x: 0.5, y: 1 }}
      >
        <TouchableOpacity>
          <NotificationIcon />
        </TouchableOpacity>
      </LinearGradient>
    </View>
  );
};

export default memo(HomeHeader);

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 10,
    marginTop: 20,
  },
  profileContainer: {
    width: 60,
    height: 60,
    borderRadius: 30, // Fixed to create a circular profile image container
    overflow: "hidden",
  },
  profileImage: {
    width: "100%",
    height: "100%",
    resizeMode: "cover", // Ensures the image fits well within the container
  },
  greetingContainer: {
    flex: 1,
    marginLeft: 10,
  },
  greetingText: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#018AD8", // Static color, can be adjusted for theming if needed
  },
  userName: {
    fontSize: 14,
    color: "#555", // Default color
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 20,
    elevation: 3,
  },
});
