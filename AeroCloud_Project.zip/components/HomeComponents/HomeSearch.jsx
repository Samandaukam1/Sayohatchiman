import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import React from "react";
import SVGImages from "../../assets/images/SVGIcons";
import { FontAwesome6 } from "@expo/vector-icons";
import { router } from "expo-router";
import { ThemedText } from "../ThemedText";
import { Colors } from "../../constants/Colors";
import { useColorScheme } from "../../hooks/useColorScheme";
import { LinearGradient } from "expo-linear-gradient";

const HomeSearch = () => {
  const colorScheme = useColorScheme();

  const handleSearchPress = () => {
    router.push("SearchPage");
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <ThemedText type="title" style={styles.heading}>
          Where do you want to explore today?
        </ThemedText>
      </View>
      <View style={styles.findProduct}>
        <LinearGradient
          colors={Colors[colorScheme ?? "light"].packageButton}
          style={[styles.searchBarContainer]}
          start={{ x: 0.5, y: 0 }}
          end={{ x: 0.5, y: 1 }}
        >
          <TouchableOpacity
            onPress={handleSearchPress}
            style={styles.searchBar}
          >
            <Text style={styles.searchText}>Search</Text>
            <View style={styles.searchIconContainer}>
              <FontAwesome6 name="magnifying-glass" color="grey" size={16} />
            </View>
          </TouchableOpacity>
        </LinearGradient>
        <TouchableOpacity style={styles.filterIconContainer}>
          <SVGImages.FilterIcon />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default HomeSearch;

const styles = StyleSheet.create({
  container: {
    paddingTop: 20,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  heading: {
    fontSize: 24,
    lineHeight: 27,
    marginBottom: 8,
  },
  filterIconContainer: {
    width: 60,
    height: 60,
    alignItems: "center",
  },
  findProduct: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    flex: 1,
    borderRadius: 10,
  },
  searchBarContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderRadius: 10,
    paddingVertical: 5,
    paddingHorizontal: 10,
    paddingLeft: 15,
    marginBottom: 20,
    width: "85%",
    height: 50,
  },
  searchIconContainer: {
    marginRight: 10,
  },
  searchText: {
    fontSize: 16,
    color: "grey",
  },
});
