import { StyleSheet, Text, View } from "react-native";
import React from "react";
import { LinearGradient } from "expo-linear-gradient";
import { FontAwesome6, Ionicons } from "@expo/vector-icons";
import { useColorScheme } from "../../hooks/useColorScheme";
import { Colors } from "../../constants/Colors";
import { ThemedText } from "../ThemedText";

// Component accepting selectedPackage as a prop
const WhatIncluded = React.memo(({ selectedPackage }) => {
  const ColorScheme = useColorScheme();
  const theme = Colors[ColorScheme ?? "light"];

  return (
    <View style={styles.container}>
      <View style={styles.row}>
        <View style={styles.flexItem}>
          <LinearGradient
            colors={theme.packageButton}
            style={styles.gradientBorder}
          >
            <View style={[styles.includedItem]}>
              <FontAwesome6 name="utensils" size={20} color="#0071C3" />
              <View>
                <ThemedText style={styles.includeHeading}>Food</ThemedText>
                <ThemedText style={styles.includedText}>
                  {selectedPackage.food}
                </ThemedText>
              </View>
            </View>
          </LinearGradient>
        </View>
        <View style={styles.flexItem}>
          <LinearGradient
            colors={theme.packageButton}
            style={styles.gradientBorder}
          >
            <View style={[styles.includedItem]}>
              <Ionicons name="time" size={20} color="#0071C3" />
              <View>
                <ThemedText style={styles.includeHeading}>Duration</ThemedText>
                <ThemedText style={styles.includedText}>
                  {selectedPackage.duration}
                </ThemedText>
              </View>
            </View>
          </LinearGradient>
        </View>
      </View>
      <View style={styles.row}>
        <View style={styles.flexItem}>
          <LinearGradient
            colors={theme.packageButton}
            style={styles.gradientBorder}
          >
            <View style={[styles.includedItem]}>
              <FontAwesome6 name="bus" size={20} color="#0071C3" />
              <View>
                <ThemedText style={styles.includeHeading}>
                  Transportation
                </ThemedText>
                <ThemedText style={styles.includedText}>
                  {selectedPackage.transportation}
                </ThemedText>
              </View>
            </View>
          </LinearGradient>
        </View>
        <View style={styles.flexItem}>
          <LinearGradient
            colors={theme.packageButton}
            style={styles.gradientBorder}
          >
            <View style={[styles.includedItem]}>
              <FontAwesome6 name="location-dot" size={24} color="#0071C3" />
              <View>
                <ThemedText style={styles.includeHeading}>Location</ThemedText>
                <ThemedText style={styles.includedText}>
                  {selectedPackage.location}
                </ThemedText>
              </View>
            </View>
          </LinearGradient>
        </View>
      </View>
    </View>
  );
});

export default WhatIncluded;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  gradientBorder: {
    flex: 1,
    margin: 5,
    borderRadius: 10,
  },
  includedItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: 10,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: "transparent",
    flex: 1,
    gap: 10,
  },
  includedText: {
    fontSize: 12,
    marginRight: 15,
    flexWrap: "wrap",
  },
  includeHeading: {
    fontSize: 14,
    fontFamily: "Poppins_600SemiBold",
  },
  row: {
    flexDirection: "row",
    marginVertical: 5,
  },
  flexItem: {
    flex: 1,
  },
});
