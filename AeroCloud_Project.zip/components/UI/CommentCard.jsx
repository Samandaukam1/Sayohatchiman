import React, { useState } from "react";
import { View, Text, StyleSheet, Image, TouchableOpacity } from "react-native";
import { useColorScheme } from "../../hooks/useColorScheme";
import { Colors } from "../../constants/Colors";
import { ThemedText } from "../../components/ThemedText";
import { LinearGradient } from "expo-linear-gradient";
import SVGImages from "../../assets/images/SVGIcons";
import { Feather } from "@expo/vector-icons";
const CommentCard = ({ comment }) => {
  const ColorScheme = useColorScheme();
  const [showFullDescription, setShowFullDescription] = useState(false);

  // Function to toggle between showing the full review or truncated version
  const toggleDescription = () => {
    setShowFullDescription(!showFullDescription);
  };

  // Truncate description if it's longer than 20 characters
  const truncatedDescription =
    comment.reviewDescription.length > 60
      ? comment.reviewDescription.substring(0, 60) + "..."
      : comment.reviewDescription;

  return (
    <LinearGradient
      colors={Colors[ColorScheme ?? "light"].socialLoginBG}
      style={styles.card}
    >
      <View
        style={[
          styles.subcard,
          { borderColor: Colors[ColorScheme ?? "light"].inputBorder },
        ]}
      >
        <View style={styles.topSection}>
          {/* Profile Image */}
          <Image
            source={{ uri: comment.profileImage }}
            style={styles.profileImage}
          />

          {/* Name and Comment Date */}
          <View style={styles.nameAndDate}>
            <ThemedText style={styles.name}>{comment.name}</ThemedText>
            <Text style={styles.commentDate}>
              {" "}
              <SVGImages.StarReview /> {comment.commentDate}
            </Text>
          </View>
        </View>

        {/* Review Heading */}
        <ThemedText style={styles.reviewHeading}>
          {comment.reviewHeading}
        </ThemedText>

        {/* Review Description */}
        <Text
          style={[
            styles.reviewDescription,
            { color: Colors[ColorScheme ?? "light"].commentDescription },
          ]}
        >
          {showFullDescription
            ? comment.reviewDescription
            : truncatedDescription}
        </Text>

        {/* 'Read All' toggle link */}
        {comment.reviewDescription.length > 20 && (
          <TouchableOpacity onPress={toggleDescription}>
            <ThemedText style={styles.readAllText}>
              {showFullDescription ? "Show Less" : "Read All"}
            </ThemedText>
          </TouchableOpacity>
        )}

        {/* Visited Date */}
        <View style={styles.bottomContainer}>
          <View>
            <Text style={styles.visitedDate}>
              <Text style={styles.boldText}>Visited Date: </Text>
            </Text>
            <Text style={styles.visitedDate}>{comment.visitedDate}</Text>
          </View>
          <Feather
            name="arrow-up-circle"
            size={24}
            color={Colors[ColorScheme ?? "light"].text}
          />
        </View>
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  card: {
    borderRadius: 10,

    marginBottom: 10,
  },
  subcard: {
    padding: 15,
    borderWidth: 1,
    borderRadius: 15,
  },
  topSection: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
  },
  profileImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  nameAndDate: {
    flexDirection: "column",
  },
  name: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 5,
  },
  commentDate: {
    fontSize: 12,
    color: "#666",
  },
  reviewHeading: {
    fontSize: 16,
    fontWeight: "bold",
    marginVertical: 10,
  },
  reviewDescription: {
    fontSize: 14,
    lineHeight: 22,
    marginBottom: 10,
  },
  readAllText: {
    textDecorationLine: "underline",
    fontSize: 14,
    marginBottom: 10,
  },
  visitedDate: {
    fontSize: 12,
    color: "#666",
  },
  boldText: {
    fontWeight: "bold",
  },
  bottomContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
});

export default CommentCard;
