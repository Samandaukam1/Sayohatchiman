import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Image,
} from "react-native";
import React, { useState } from "react";
import { useColorScheme } from "../../hooks/useColorScheme";
import { Colors } from "../../constants/Colors";
import { ThemedText } from "../../components/ThemedText";
import { LinearGradient } from "expo-linear-gradient";
import Swiper from "react-native-swiper";
import TouristPlaces from "../../helpers/mock";
import CommentsImg from "../../assets/images/Images/Comments.png";
import { FontAwesome6 } from "@expo/vector-icons";
const SearchRelatedProduct = () => {
  const [activeCategory, setActiveCategory] = useState("All");
  const colorScheme = useColorScheme();

  const filterPlacesByCategory = (category) => {
    return TouristPlaces.filter((place) => {
      if (category === "All") return true;
      return place.category === category;
    });
  };

  const categories = [
    "All",
    "Popular",
    "Recommended",
    "Best Visited",
    "Most Viewed",
  ];

  const truncateText = (text, length) => {
    if (text.length <= length) return text;
    return text.substring(0, length) + "...";
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <ThemedText style={styles.headerTitle}>Related Products</ThemedText>
      </View>
      <View style={styles.categoryContainer}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoryScroll}
        >
          {categories.map((category, index) => (
            <TouchableOpacity
              key={index}
              style={[
                styles.categoryItem,
                activeCategory === category && styles.activeCategoryItem,
              ]}
              onPress={() => setActiveCategory(category)}
            >
              <ThemedText
                style={[
                  styles.categoryText,
                  activeCategory === category && styles.activeCategoryText,
                ]}
              >
                {category}
              </ThemedText>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <Swiper
        containerStyle={styles.swiperContainer}
        paginationStyle={styles.paginationStyle}
        showsPagination={true}
        dot={<View style={styles.paginationDot} />}
        activeDot={<View style={styles.paginationActiveDot} />}
        loop={false}
      >
        {filterPlacesByCategory(activeCategory).map((place, index) => (
          <View key={index} style={styles.cardWrapper}>
            <LinearGradient
              colors={Colors[colorScheme ?? "light"].socialLoginBG}
              style={styles.gradientBackground}
              start={{ x: 0.5, y: 0 }}
              end={{ x: 0.5, y: 1 }}
            >
              <TouchableOpacity style={styles.cardContent}>
                <View style={styles.imageContainer}>
                  <Image source={place.image} style={styles.image} />
                </View>
                <View style={styles.detailsContainer}>
                  <ThemedText style={styles.name}>
                    {truncateText(place.name, 10)}
                  </ThemedText>
                  <ThemedText style={styles.location}>
                    <FontAwesome6
                      name="location-dot"
                      size={18}
                      color="#0071C3"
                    />
                    <Text> {truncateText(place.location, 13)}</Text>
                  </ThemedText>
                  <View style={styles.commentContainer}>
                    <Image source={CommentsImg} style={styles.profileImage} />
                    <ThemedText style={styles.comments}>
                      {place.reviewsCount} reviews
                    </ThemedText>
                  </View>
                </View>
              </TouchableOpacity>
            </LinearGradient>
          </View>
        ))}
      </Swiper>
    </View>
  );
};

export default SearchRelatedProduct;

const styles = StyleSheet.create({
  container: {
    minHeight: 300,
    maxHeight: 460,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 20,
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: "bold",
  },
  headerLink: {
    fontSize: 16,
    color: "#018ADB",
  },
  categoryContainer: {
    marginVertical: 10,
  },
  categoryScroll: {},
  categoryItem: {
    marginHorizontal: 10,
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 20,
  },
  categoryText: {
    fontSize: 16,
  },
  activeCategoryText: {
    color: "#018AD5",
    fontFamily: "Poppins_700Bold",
  },
  swiperContainer: {
    flex: 1,
    height: 200,
  },
  cardWrapper: {
    width: "90%",
    marginHorizontal: 10,
    marginTop: 20,
    marginBottom: 40,
  },
  gradientBackground: {
    borderRadius: 10,
    overflow: "hidden",
    elevation: 3,
  },
  cardContent: {
    flexDirection: "row",
    borderRadius: 10,
    padding: 10,
  },
  imageContainer: {
    width: 140,
    height: 94,
    borderRadius: 10,
    overflow: "hidden",
  },
  image: {
    width: "100%",
    height: "100%",
    resizeMode: "cover",
  },
  detailsContainer: {
    flex: 1,
    padding: 10,
  },
  name: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 5,
  },
  location: {
    fontSize: 14,
    marginBottom: 5,
    gap: 10,
    flexDirection: "row",
  },
  comments: {
    fontSize: 12,
  },
  paginationStyle: {
    bottom: -10,
  },
  paginationDot: {
    width: 6,
    height: 6,
    borderRadius: 4,
    backgroundColor: "rgba(1, 138, 219,0.4)",
    marginHorizontal: 4,
  },
  paginationActiveDot: {
    width: 23,
    height: 6,
    borderRadius: 6,
    backgroundColor: "#0071C3",
    marginHorizontal: 4,
  },
  commentContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 5,
    gap: 5,
  },
});
