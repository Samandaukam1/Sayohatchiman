import React, { useMemo } from "react";
import { Modal, View, Button, StyleSheet } from "react-native";
import { useColorScheme } from "../../hooks/useColorScheme";
import { Colors } from "../../constants/Colors";
import { ThemedText } from "../../components/ThemedText";
import { LinearGradient } from "expo-linear-gradient";

const LogoutModal = ({ visible, onCancel, onConfirm }) => {
  const colorScheme = useColorScheme();

  // Use useMemo to avoid recomputing the colors on every render
  const backgroundColors = useMemo(() => {
    return Colors[colorScheme ?? "light"].socialLoginBG;
  }, [colorScheme]);

  return (
    <Modal
      transparent
      visible={visible}
      animationType="fade"
      onRequestClose={onCancel}
    >
      <View style={styles.modalOverlay}>
        <LinearGradient colors={backgroundColors} style={styles.modalContent}>
          <ThemedText style={styles.modalTitle}>Confirm Logout</ThemedText>
          <ThemedText style={styles.modalMessage}>
            Are you sure you want to logout?
          </ThemedText>
          <View style={styles.buttonContainer}>
            <Button title="Cancel" onPress={onCancel} />
            <Button title="Confirm" onPress={onConfirm} />
          </View>
        </LinearGradient>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0,0.9)", // Dark semi-transparent background
  },
  modalContent: {
    width: 300,
    padding: 20,
    borderRadius: 10,
    alignItems: "center",
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 10,
  },
  modalMessage: {
    fontSize: 16,
    marginBottom: 20,
    textAlign: "center",
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
  },
});

export default React.memo(LogoutModal);
