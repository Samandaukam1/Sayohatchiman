import React, { useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { Entypo, Ionicons } from "@expo/vector-icons";
import { useColorScheme } from "../../hooks/useColorScheme";
import { Colors } from "../../constants/Colors";

export default function MyCheckbox() {
  const [checked, setChecked] = useState(false);

  const ColorScheme = useColorScheme();

  return (
    <Pressable
      style={[
        styles.checkboxBase,
        checked && styles.checkboxChecked,
        { borderColor: Colors[ColorScheme ?? "light"].text },
      ]}
      onPress={() => setChecked(!checked)}
    >
      {checked && (
        <Entypo
          name="check"
          size={12}
          color={Colors[ColorScheme ?? "light"].text}
        />
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  checkboxBase: {
    width: 18,
    height: 18,
    borderRadius: 4,
    borderWidth: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  checkboxChecked: {},
});
