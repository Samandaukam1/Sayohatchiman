import { ScrollView, StyleSheet, Text, View, Pressable } from "react-native";
import React, { useState } from "react";
import { LinearGradient } from "expo-linear-gradient";
import { ThemedText } from "../ThemedText";
import { useColorScheme } from "../../hooks/useColorScheme";
import { Colors } from "../../constants/Colors";
import CheckedBox from "../../assets/images/SVGIcons/CheckedBox";
import ColoredCheckBox from "../../assets/images/SVGIcons/ColoredCheckedBox";

const budgetOptions = [
  {
    id: 1,
    name: "Only Me 🚶🏻",
    description: "Travel Solo",
  },
  {
    id: 2,
    name: "Couple 👫🏻",
    description: "A love gateway",
  },
  {
    id: 3,
    name: "Family 👨‍👩‍👧‍👦",
    description: "Time with your loved ones",
  },
  {
    id: 4,
    name: "Friends 👬",
    description: "Fun times",
  },
];

const ChoosePackage = () => {
  const [checkedItemId, setCheckedItemId] = useState(null);
  const ColorScheme = useColorScheme();

  const handleCheckboxChange = (id) => {
    setCheckedItemId(id);
  };

  return (
    <View style={styles.container}>
      <ThemedText style={styles.heading}>Going as a? 💼 </ThemedText>
      <ThemedText style={styles.subheading}>
        Metus dictum at tempor commodo ullamcorper a lacus vestibulum?
      </ThemedText>

      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.budgetContainer}>
          {budgetOptions.map((item) => {
            const isChecked = checkedItemId === item.id;
            return (
              <Pressable
                key={item.id}
                onPress={() => handleCheckboxChange(item.id)}
                style={styles.budgetWrapper}
              >
                {isChecked ? (
                  <LinearGradient
                    colors={["#0071C3", "#33B2FF"]}
                    start={[0, 0]}
                    end={[1, 1]}
                    style={styles.budgetItem}
                  >
                    <View style={styles.budgetText}>
                      <ThemedText
                        style={[styles.budgetHeading, styles.budgetTextChecked]}
                      >
                        {item.name}
                      </ThemedText>
                      <Text style={[styles.budgetTextChecked]}>
                        {item.description}
                      </Text>
                      <Text style={styles.budgetTextChecked}>{item.price}</Text>
                    </View>
                    <ColoredCheckBox />
                  </LinearGradient>
                ) : (
                  <LinearGradient
                    colors={Colors[ColorScheme ?? "light"].socialLoginBG}
                    start={[0, 0]}
                    end={[1, 1]}
                    style={styles.budgetItem}
                  >
                    <View style={styles.budgetText}>
                      <ThemedText style={styles.budgetHeading}>
                        {item.name}
                      </ThemedText>
                      <ThemedText>{item.description}</ThemedText>
                      <ThemedText>{item.price}</ThemedText>
                    </View>
                    <CheckedBox />
                  </LinearGradient>
                )}
              </Pressable>
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
};

export default ChoosePackage;

const styles = StyleSheet.create({
  container: {
    marginTop: 10,
  },
  heading: {
    fontFamily: "Poppins_700Bold",
    fontSize: 22,
    marginBottom: 10,
  },
  subheading: {
    fontSize: 16,
    marginBottom: 20,
    color: "#666",
  },
  budgetContainer: {
    paddingBottom: 20,
  },
  budgetWrapper: {
    marginBottom: 20,
    borderRadius: 20,
    overflow: "hidden",
  },
  budgetItem: {
    borderWidth: 2,
    borderColor: "#CCCCCC",
    padding: 15,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderRadius: 20,
  },
  budgetText: {
    flex: 1,
  },
  budgetHeading: {
    fontSize: 18,
    fontFamily: "Poppins_700Bold",
  },
  budgetTextChecked: {
    color: "white",
  },
});
