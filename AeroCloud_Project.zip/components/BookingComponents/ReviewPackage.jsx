import {
  Image,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
} from "react-native";
import React from "react";
import CoupleIcon from "../../assets/images/SVGIcons/CoupleIcon";
import BudjetIcon from "../../assets/images/SVGIcons/BudjetIcon";
import CalendarIcon from "../../assets/images/SVGIcons/CalendarIcon";
import { Feather, Ionicons } from "@expo/vector-icons";
import GoaImage from "../../assets/images/Images/GoaImage.webp";
import SVGImages from "../../assets/images/SVGIcons";
import { ThemedText } from "../ThemedText";
import LocationIcon from "../../assets/images/SVGIcons/LocationIcon";

const ReviewPackage = () => {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.itemContainer}>
        <LocationIcon />
        <View style={styles.textContainer}>
          <ThemedText style={styles.label}>Destination</ThemedText>
          <View style={styles.subItemContainer}>
            <Image source={GoaImage} style={styles.image} />
            <View style={styles.locationTextContainer}>
              <ThemedText style={styles.locationName}>Misty Resort</ThemedText>
              <ThemedText>Goa, Maharashtra</ThemedText>
              <SVGImages.StarReview />
            </View>
            <TouchableOpacity onPress={() => console.log("Edit destination")}>
              <Feather
                name="edit"
                style={styles.editIcon}
                size={20}
                color="rgba(51, 178, 255, 1)"
              />
            </TouchableOpacity>
          </View>
        </View>
      </View>
      <View style={styles.itemContainer}>
        <CoupleIcon style={styles.icon} />
        <View style={styles.textContainer}>
          <ThemedText style={styles.label}>Persons</ThemedText>
          <ThemedText>Couple 👫🏻</ThemedText>
        </View>
        <TouchableOpacity onPress={() => console.log("Edit persons")}>
          <Feather
            name="edit"
            style={styles.editIcon}
            size={20}
            color="rgba(51, 178, 255, 1)"
          />
        </TouchableOpacity>
      </View>
      <View style={styles.itemContainer}>
        <CalendarIcon style={styles.icon} />
        <View style={styles.textContainer}>
          <ThemedText style={styles.label}>Trip Date</ThemedText>
          <ThemedText>March 20, 2024 to May 20, 2024 🗓</ThemedText>
        </View>
        <TouchableOpacity onPress={() => console.log("Edit trip date")}>
          <Feather
            name="edit"
            style={styles.editIcon}
            size={20}
            color="rgba(51, 178, 255, 1)"
          />
        </TouchableOpacity>
      </View>
      <View style={styles.itemContainer}>
        <BudjetIcon style={styles.icon} />
        <View style={styles.textContainer}>
          <ThemedText style={styles.label}>Budget</ThemedText>
          <ThemedText>Luxury 💎</ThemedText>
        </View>
        <TouchableOpacity onPress={() => console.log("Edit budget")}>
          <Feather
            name="edit"
            style={styles.editIcon}
            size={20}
            color="rgba(51, 178, 255, 1)"
          />
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

export default ReviewPackage;

const styles = StyleSheet.create({
  container: {},
  heading: {
    fontSize: 24,
    marginBottom: 20,
    paddingHorizontal: 20,
    textAlign: "center",
  },
  itemContainer: {
    flexDirection: "row",
    marginBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: "#ccc",
    paddingBottom: 20,
  },
  icon: {
    fontSize: 24,
    marginRight: 10,
  },
  textContainer: {
    flex: 1,
  },
  label: {
    fontFamily: "Poppins_700Bold",
    marginBottom: 8,
    fontSize: 18,
  },
  subItemContainer: {
    flexDirection: "row",
  },
  image: {
    width: 150,
    height: 90,
    borderRadius: 10,
    marginRight: 10,
  },
  locationTextContainer: {
    flex: 1,
  },
  locationName: {
    fontWeight: "bold",
  },
});
