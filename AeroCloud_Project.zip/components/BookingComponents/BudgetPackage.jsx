import { ScrollView, StyleSheet, Text, View, Pressable } from "react-native";
import React, { useState } from "react";
import { LinearGradient } from "expo-linear-gradient";
import { ThemedText } from "../ThemedText";
import ColoredCheckBox from "../../assets/images/SVGIcons/ColoredCheckedBox";
import CheckedBox from "../../assets/images/SVGIcons/CheckedBox";

const budgetOptions = [
  {
    id: 1,
    name: "Cheap 💰",
    description: "Budget-friendly amount",
    price: "600/person",
  },
  {
    id: 2,
    name: "Balanced 💴",
    description: "Moderate Spending Money",
    price: "600/person",
  },
  {
    id: 3,
    name: "Flexible 💸",
    description: "No budget restriction",
    price: "600/person",
  },
  {
    id: 4,
    name: "Luxury 💎",
    description: "High-budget",
    price: "1600/person",
  },
];

const BudgetPackage = () => {
  const [checkedItemId, setCheckedItemId] = useState(null);
  const handleCheckboxChange = (id) => {
    setCheckedItemId(id);
  };

  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <View style={styles.container}>
        <ThemedText type="title" style={styles.heading}>
          Set your trip budget? 💸
        </ThemedText>
        <ThemedText style={styles.subheading}>
          Metus dictum at tempor commodo ullamcorper a lacus vestibulum?
        </ThemedText>

        <View style={styles.budgetContainer}>
          {budgetOptions.map((item) => {
            const isChecked = checkedItemId === item.id;
            return (
              <Pressable
                key={item.id}
                onPress={() => handleCheckboxChange(item.id)}
                style={styles.budgetWrapper}
              >
                {isChecked ? (
                  <LinearGradient
                    colors={["#0071C3", "#33B2FF"]}
                    start={[0, 0]}
                    end={[1, 1]}
                    style={styles.budgetItem}
                  >
                    <View style={styles.budgetText}>
                      <Text
                        style={[styles.budgetHeading, styles.budgetTextChecked]}
                      >
                        {item.name}
                      </Text>
                      <Text style={styles.budgetTextChecked}>
                        {item.description}
                      </Text>
                      <Text style={styles.budgetTextChecked}>
                        $ {item.price}
                      </Text>
                    </View>
                    <ColoredCheckBox />
                  </LinearGradient>
                ) : (
                  <View style={styles.budgetItem}>
                    <View style={styles.budgetText}>
                      <ThemedText style={styles.budgetHeading}>
                        {item.name}
                      </ThemedText>
                      <ThemedText>{item.description}</ThemedText>
                      <ThemedText>$ {item.price}</ThemedText>
                    </View>
                    <CheckedBox />
                  </View>
                )}
              </Pressable>
            );
          })}
        </View>
      </View>
    </ScrollView>
  );
};

export default BudgetPackage;

const styles = StyleSheet.create({
  container: {},
  heading: {
    fontFamily: "Poppins_700Bold",
    fontSize: 22,
    marginBottom: 10,
  },
  subheading: {
    fontSize: 16,
    marginBottom: 20,
    color: "#666",
  },
  budgetContainer: {
    paddingBottom: 20,
  },
  budgetWrapper: {
    marginBottom: 20,
    borderRadius: 20,
    overflow: "hidden",
  },
  budgetItem: {
    borderWidth: 2,
    borderColor: "#CCCCCC",
    padding: 15,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderRadius: 20,
  },
  budgetText: {
    flex: 1,
  },
  budgetHeading: {
    fontSize: 18,
    fontFamily: "Poppins_700Bold",
  },
  budgetTextChecked: {
    color: "white",
  },
});
