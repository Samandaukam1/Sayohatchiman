import React, { useState } from "react";
import { StyleSheet, View } from "react-native";
import { Calendar } from "react-native-calendars";
import { ThemedText } from "../ThemedText";
import { useColorScheme } from "../../hooks/useColorScheme";
import { Colors } from "../../constants/Colors";
import { LinearGradient } from "expo-linear-gradient";
import moment from "moment"; // Import moment for date comparison

const CalendarPage = () => {
  const [selected, setSelected] = useState("");
  const colorScheme = useColorScheme();

  // Handles day press and sets the selected date
  const handleDayPress = (day) => {
    setSelected(day.dateString);
  };

  // Get today's date to disable past dates
  const today = moment().format("YYYY-MM-DD");

  return (
    <View style={styles.container}>
      {/* Title and subtitle */}
      <ThemedText type="title" style={styles.heading}>
        When will your adventure begin and end? 🗓
      </ThemedText>
      <ThemedText style={styles.subheading}>
        Metus dictum at tempor commodo ullamcorper a lacus vestibulum?
      </ThemedText>

      {/* Calendar with LinearGradient */}
      <LinearGradient
        colors={Colors[colorScheme ?? "light"].socialLoginBG}
        start={[0, 0]}
        end={[1, 1]}
        style={styles.gradient}
      >
        <View style={styles.calendarContainer}>
          <Calendar
            onDayPress={handleDayPress}
            markedDates={{
              [selected]: {
                selected: true,
                disableTouchEvent: true,
                selectedDotColor: "orange",
              },
            }}
            minDate={today} // Disable past dates
            style={styles.calendar}
            theme={{
              calendarBackground: "transparent", // Make the background of the calendar transparent
              textSectionTitleColor: Colors[colorScheme ?? "light"].text,
              selectedDayBackgroundColor: "#0071C3",
              selectedDayTextColor: "white",
              todayTextColor: "#0071C3",
              dayTextColor: Colors[colorScheme ?? "light"].text,
              textDisabledColor: "#d9e1e8", // Set the color for disabled dates
              arrowColor: Colors[colorScheme ?? "light"].primary,
              monthTextColor: Colors[colorScheme ?? "light"].text,
            }}
          />
        </View>
      </LinearGradient>
    </View>
  );
};

export default CalendarPage;

// Optimized and organized styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  gradient: {
    borderRadius: 15,
    elevation: 5, // Elevation moved to gradient container
    marginVertical: 25,
    padding: 10, // Added padding inside the gradient to create space around the calendar
  },
  calendarContainer: {
    borderRadius: 15, // Rounded corners for the calendar container
    overflow: "hidden", // Ensure the calendar respects the border radius
  },
  calendar: {
    borderRadius: 15,
  },
  heading: {
    fontSize: 22,
    marginBottom: 10,
  },
  subheading: {
    fontSize: 16,
    marginBottom: 20,
  },
});
