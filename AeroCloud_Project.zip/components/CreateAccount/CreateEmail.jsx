import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import React, { useState } from "react";
import InputComponent from "../InputComponent/InputComponent";
import { ThemedText } from "../ThemedText";
import { ThemedView } from "../ThemedView";
const CreateEmail = () => {
  const [email, setEmail] = useState("");

  return (
    <ThemedView style={styles.container}>
      <ScrollView>
        <ThemedText style={styles.subHeading}>Create New Account</ThemedText>
        <ThemedText type="title" style={styles.heading}>
          Enter Your Email
        </ThemedText>
        <InputComponent
          label="Email"
          placeholder="willie.jennings@example.com"
          value={email}
          onChangeText={setEmail}
        />

        <ThemedText style={styles.description}>
          Proin fermentum leo vel orci non pulvinar neque ornar eget egestas
          purus risus ultricies.
        </ThemedText>
      </ScrollView>
    </ThemedView>
  );
};

export default CreateEmail;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 30,
  },
  heading: {
    fontSize: 30,
    marginBottom: 10,
  },
  subHeading: {
    color: "#474747",
    fontSize: 16,
    marginBottom: 10,
    marginTop: 10,
  },
  backButton: {
    marginBottom: 15,
  },
  description: {
    fontSize: 13,
    marginBottom: 10,
  },
});
