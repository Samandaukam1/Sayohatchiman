import { ScrollView, StyleSheet, Text, View } from "react-native";
import React, { useState } from "react";
import InputComponent from "../InputComponent/InputComponent";
import { ThemedText } from "../ThemedText";

const CreateName = () => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");

  return (
    <View style={styles.container}>
      <ScrollView>
        <ThemedText style={styles.subHeading}>Create New Account</ThemedText>
        <ThemedText type="title" style={styles.heading}>
          What’s Your Name?
        </ThemedText>
        <InputComponent
          label="First Name"
          placeholder="Johnty "
          value={firstName}
          onChangeText={setFirstName}
        />
        <InputComponent
          label="Last Name"
          placeholder="Rhodes"
          value={lastName}
          onChangeText={setLastName}
        />
      </ScrollView>
    </View>
  );
};

export default CreateName;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 30,
  },
  heading: {
    fontSize: 30,
    marginBottom: 10,
  },
  subHeading: {
    color: "#474747",
    fontSize: 16,
    marginBottom: 10,
    marginTop: 10,
  },
  backButton: {
    marginBottom: 15,
  },
});
