import { ScrollView, StyleSheet, Text, View } from "react-native";
import React, { useState } from "react";
import { router } from "expo-router";
import InputComponent from "../InputComponent/InputComponent";
import { ThemedText } from "../ThemedText";
import { ThemedView } from "../ThemedView";
const CreatePassword = () => {
  const [password, setPassword] = useState("");
  const goBack = () => {
    router.back();
  };
  return (
    <ThemedView style={styles.container}>
      <ScrollView>
        <ThemedText style={styles.subHeading}>Create New Account</ThemedText>
        <ThemedText style={styles.heading} type="title">
          Create a password
        </ThemedText>
        <InputComponent
          label="New Password"
          placeholder="Enter your password"
          value={password}
          onChangeText={setPassword}
        />
        <ThemedText style={styles.description}>
          Proin fermentum leo vel orci non pulvinar neque ornar eget egestas
          purus risus ultricies.
        </ThemedText>
      </ScrollView>
    </ThemedView>
  );
};

export default CreatePassword;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 30,
  },
  heading: {
    fontSize: 30,
    marginBottom: 10,
  },
  subHeading: {
    color: "#474747",
    fontSize: 16,
    marginBottom: 10,
    marginTop: 10,
  },
  backButton: {
    marginBottom: 15,
  },
  description: {
    fontSize: 13,
    marginBottom: 10,
  },
});
