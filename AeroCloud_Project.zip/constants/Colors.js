const tintColorLight = "#0a7ea4";
const tintColorDark = "#fff";

export const Colors = {
  light: {
    background: "#fff",
    text: "#000",
    onboardingBoxBg: "rgba(241, 241, 241, 1)",
    inputBorder: "#cccccc",
    placeholderColor: "#858585",
    socialLoginBG: ["white", "white"],
    commentDescription: "rgba(0,0,0, 0.5)",
    packageButton: ["#f1f1f1", "#f1f1f1"],
    inputBorder: "#cccccc",
    authBorder: "#cccccc",
  },
  dark: {
    background: "#050717",
    text: "#fff",
    onboardingBoxBg: "rgba(241, 241, 241, 0.05)",
    inputBorder: "#404040",
    placeholderColor: "#888888",
    socialLoginBG: ["rgba(124, 124, 124, 0.25)", "rgba(242, 242, 242, 0.06)"],
    commentDescription: "#f1f1f1",
    packageButton: ["rgba(124, 124, 124, 0.25)", "rgba(242, 242, 242, 0.06)"],
    inputBorder: "transparent",
    authBorder: "#404040",
  },
};
