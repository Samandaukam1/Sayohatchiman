import { StyleSheet, Text, View, TouchableOpacity, Alert } from "react-native";
import React, { useState } from "react";
import PersonalIcon from "../../assets/images/SVGIcons/PersonalIcon";
import LogoutIcon from "../../assets/images/SVGIcons/LogoutIcon";
import SecurityIcon from "../../assets/images/SVGIcons/SecurityIcon";
import StarIcon from "../../assets/images/SVGIcons/StarIcon";
import PreferenceIcon from "../../assets/images/SVGIcons/PreferenceIcon";
import HelpIcon from "../../assets/images/SVGIcons/HelpIcon";
import { AntDesign, FontAwesome6 } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import SVGImages from "../../assets/images/SVGIcons";

import { useColorScheme } from "../../hooks/useColorScheme";
import { Colors } from "../../constants/Colors";
import { ThemedView } from "../../components/ThemedView";
import { ThemedText } from "../../components/ThemedText";
import { router } from "expo-router";
import LogoutModal from "../../components/UI/LogoutModal";

const settingsOptions = [
  {
    icon: <PersonalIcon />,
    text: "Shaxsiy ma'lumotlar",
    onPress: () => Alert.alert("Shaxsiy ma'lumotlar"),
  },
  {
    icon: <HelpIcon />,
    text: "Yordam va qo‘llab-quvvatlash",
    onPress: () => Alert.alert("Yordam va qo‘llab-quvvatlash"),
  },
  {
    icon: <PreferenceIcon />,
    text: "Sayohat afzalliklari",
    onPress: () => Alert.alert("Sayohat afzalliklari"),
  },
  {
    icon: <StarIcon />,
    text: "Hisob-kitob va obunalar",
    onPress: () => Alert.alert("Hisob-kitob va obunalar"),
  },
  {
    icon: <SecurityIcon />,
    text: "Hisob va xavfsizlik",
    onPress: () => Alert.alert("Hisob va xavfsizlik"),
  },
];

const Settings = () => {
  const navigation = useNavigation();
  const ColorScheme = useColorScheme();
  const [modalVisible, setModalVisible] = useState(false);

  const handleLogoutPress = () => {
    setModalVisible(true); // Modalni ko‘rsatish
  };

  const handleCancel = () => {
    setModalVisible(false); // Modalni yashirish
  };

  const handleConfirmLogout = () => {
    setModalVisible(false); // Modalni yashirish
    navigation.navigate("Login"); // Login sahifasiga o‘tish
  };

  return (
    <ThemedView style={styles.container}>
      <View style={styles.headerContainer}>
        <TouchableOpacity onPress={() => router.push("Home")}>
          <AntDesign
            name="arrowleft"
            size={24}
            color={Colors[ColorScheme ?? "light"].text}
          />
        </TouchableOpacity>
        <ThemedText type="title" style={styles.header}>
          Sozlamalar
        </ThemedText>
        <View />
      </View>
      <TouchableOpacity
        style={styles.gradientTouchable}
        onPress={() => Alert.alert("Rejani yangilash")}
      >
        <LinearGradient colors={["#33B2FF", "#0071C3"]} style={styles.gradient}>
          <SVGImages.PremiumStarIcon />
          <View style={styles.upgradeTextContainer}>
            <Text style={styles.upgradeText}>Ko‘proq imkoniyatlar uchun rejani yangilang!</Text>
            <Text style={styles.upgradeSubText}>
              Barcha imkoniyatlardan foydalaning va ko‘proq narsalarni kashf eting
            </Text>
          </View>
          <FontAwesome6 name="chevron-right" color="white" size={20} />
        </LinearGradient>
      </TouchableOpacity>
      {settingsOptions.map((option, index) => (
        <TouchableOpacity
          key={index}
          style={styles.optionContainer}
          onPress={option.onPress}
        >
          <View style={styles.iconTextContainer}>
            {option.icon}
            <ThemedText style={styles.optionText}>{option.text}</ThemedText>
          </View>
          <FontAwesome6
            name="chevron-right"
            size={20}
            color={Colors[ColorScheme ?? "light"].text}
          />
        </TouchableOpacity>
      ))}
      <TouchableOpacity
        style={styles.optionContainer}
        onPress={handleLogoutPress}
      >
        <View style={styles.iconTextContainer}>
          <LogoutIcon />
          <ThemedText style={styles.optionText}>Chiqish</ThemedText>
        </View>
        <FontAwesome6
          name="chevron-right"
          size={20}
          color={Colors[ColorScheme ?? "light"].text}
        />
      </TouchableOpacity>
      <LogoutModal
        visible={modalVisible}
        onCancel={handleCancel}
        onConfirm={handleConfirmLogout}
      />
    </ThemedView>
  );
};

export default Settings;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    paddingTop: 50,
  },
  headerContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginVertical: 20,
  },
  header: {
    fontSize: 24,
  },
  themeIcon: {
    padding: 10,
  },
  gradientTouchable: {
    marginBottom: 20,
    borderRadius: 8,
    overflow: "hidden",
  },
  gradient: {
    flexDirection: "row",
    alignItems: "center",
    padding: 15,
    justifyContent: "space-between",
  },
  upgradeTextContainer: {
    marginLeft: 10,
  },
  upgradeText: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#fff",
    marginBottom: 8,
  },
  upgradeSubText: {
    fontSize: 12,
    color: "#fff",
  },
  optionContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 15,
    marginBottom: 15,
  },
  iconTextContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  optionText: {
    marginLeft: 15,
    fontSize: 16,
  },
});
