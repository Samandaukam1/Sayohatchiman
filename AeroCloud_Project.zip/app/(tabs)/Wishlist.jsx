import { StyleSheet, View } from "react-native";
import React from "react";
import { ThemedText } from "../../components/ThemedText";
import { ThemedView } from "../../components/ThemedView";

const Wishlist = () => {
  return (
    <ThemedView style={styles.container}>
      <ThemedText style={styles.heading}>Mening istaklarim ro‘yxati</ThemedText>
      <View style={styles.messageContainer}>
        <ThemedText style={styles.message}>
          Sahifa hozirda ishlab chiqilmoqda. Yangiliklar uchun kuzatishda qoling.
        </ThemedText>
        <ThemedText style={styles.quote}>"Eng yaxshisi hali oldinda."</ThemedText>
      </View>
    </ThemedView>
  );
};

export default Wishlist;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  heading: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
    marginTop: 20,
  },
  messageContainer: {
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 20,
  },
  message: {
    fontSize: 18,
    fontStyle: "italic",
    textAlign: "center",
    marginBottom: 20,
  },
  quote: {
    fontSize: 16,
    fontStyle: "italic",
    textAlign: "center",
    marginTop: 10,
  },
});
