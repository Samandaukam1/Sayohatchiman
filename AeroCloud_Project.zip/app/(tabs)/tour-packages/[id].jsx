import React, { useState, useCallback, useMemo } from "react";
import { StyleSheet, Image, View, Text, TouchableOpacity } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { TourPackages } from "../../../helpers/mock";
import ParallaxScrollView from "../../../components/ParrallaxScrollView";
import { ThemedView } from "../../../components/ThemedView";
import { FontAwesome6, Ionicons } from "@expo/vector-icons";
import CommentCard from "../../../components/UI/CommentCard";
import { LinearGradient } from "expo-linear-gradient";
import { useColorScheme } from "../../../hooks/useColorScheme";
import { Colors } from "../../../constants/Colors";
import { ThemedText } from "../../../components/ThemedText";
import CustomButton from "../../../components/CustomButton/CustomButton";
import SVGImages from "../../../assets/images/SVGIcons";
import WhatIncluded from "../../../components/UI/WhatIncluded";

// Memoize CommentCard to avoid re-renders
const MemoizedCommentCard = React.memo(CommentCard);

const getRandomComments = (comments, count) => {
  const shuffled = [...comments].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
};

const PackageDetails = () => {
  const { id } = useLocalSearchParams();
  const packageId = parseInt(id, 10);
  const selectedPackage = TourPackages.find((pkg) => pkg.id === packageId);
  const ColorScheme = useColorScheme();
  const [showFullDescription, setShowFullDescription] = useState(false);
  const [showAllComments, setShowAllComments] = useState(false);
  const [liked, isLiked] = useState(false);

  const handleLike = () => {
    isLiked(!liked);
  };

  const truncatedAbout =
    selectedPackage.about.length > 120
      ? selectedPackage.about.substring(0, 120) + "..."
      : comment.about;
  const toggleDescription = () => {
    setShowFullDescription(!showFullDescription);
  };

  const toggleComments = useCallback(() => {
    setShowAllComments((prev) => !prev);
  }, []);

  const displayedComments = useMemo(
    () => getRandomComments(selectedPackage.comments, 2),
    [selectedPackage.comments]
  );
  const remainingComments = useMemo(
    () =>
      selectedPackage.comments.length > 2
        ? selectedPackage.comments.slice(2)
        : [],
    [selectedPackage.comments]
  );
  const remainingCommentsCount = remainingComments.length;

  if (!selectedPackage) {
    return (
      <View style={styles.container}>
        <Text>Package not found.</Text>
      </View>
    );
  }

  return (
    <ThemedView style={styles.container}>
      <ParallaxScrollView
        headerImage={
          <View style={styles.headerImageContainer}>
            <Image
              source={selectedPackage.mainImage}
              style={styles.mainImage}
            />
            <LinearGradient
              colors={["transparent", "rgba(0, 0, 0, 0.8)"]}
              style={styles.bottomOverlay}
            />
            {/* Overlay Icons */}
            <View style={styles.overlayIconLeft}>
              <TouchableOpacity
                onPress={() => {
                  router.back();
                }}
                style={styles.iconButton}
              >
                <FontAwesome6 name="arrow-left-long" size={20} color="black" />
              </TouchableOpacity>
            </View>
            <View style={styles.overlayIconRight}>
              <TouchableOpacity onPress={() => {}} style={styles.iconButton}>
                <Ionicons name="share-social" size={20} color="black" />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  handleLike();
                }}
                style={styles.iconButton}
              >
                <Ionicons
                  name={liked ? "heart" : "heart-outline"}
                  size={20}
                  color={liked ? "red" : "black"}
                />
              </TouchableOpacity>
            </View>
            <View style={styles.overlayIconBottomLeft}>
              <ThemedText type="title" style={styles.title}>
                {selectedPackage.name}
              </ThemedText>
              <ThemedText style={{ color: "white" }}>
                <SVGImages.StarReview /> 100 Reviews
              </ThemedText>
            </View>
            <View style={styles.overlayIconBottomRight}>
              <TouchableOpacity style={styles.headerPhotoButton}>
                <Text style={styles.headerbtnText}>+ 100 Photos</Text>
              </TouchableOpacity>
            </View>
          </View>
        }
        headerBackgroundColor={{ light: "#FFFFFF", dark: "#000000" }}
      >
        <ThemedText type="subtitle" style={styles.subtitle}>
          About
        </ThemedText>
        <ThemedText
          style={[
            styles.about,
            { color: Colors[ColorScheme ?? "light"].commentDescription },
          ]}
        >
          {showFullDescription ? selectedPackage.about : truncatedAbout}
        </ThemedText>

        {selectedPackage.about.length > 120 && (
          <TouchableOpacity
            onPress={toggleDescription}
            style={styles.readMoreButton}
          >
            <ThemedText style={styles.readMoreText}>
              {showFullDescription ? "Read Less" : "Read More"}
            </ThemedText>
          </TouchableOpacity>
        )}
        <ThemedText type="subtitle" style={styles.subtitle}>
          What's included
        </ThemedText>
        <WhatIncluded selectedPackage={selectedPackage} />

        <ThemedText type="subtitle" style={styles.subtitle}>
          Where will you stay
        </ThemedText>
        <ThemedText>View the locaiton of the map</ThemedText>
        <SVGImages.MapImage />
        <View>
          <ThemedText type="default"> Angkor Mails Hotel</ThemedText>

          <ThemedText type="default">NR6, Krong Siem Reap Cambodia </ThemedText>
        </View>

        <View style={styles.imageContainer}>
          <View style={styles.imageColumn}>
            <Image source={selectedPackage.images[0]} style={styles.image} />
            <Image source={selectedPackage.images[1]} style={styles.image} />
          </View>
          <View style={styles.imageColumn}>
            <Image
              source={selectedPackage.images[2]}
              style={styles.imageVertical}
            />
          </View>
        </View>
        <View style={styles.showMoreContainer}>
          <LinearGradient
            colors={Colors[ColorScheme ?? "light"].packageButton}
            style={styles.showMoreTextWrapper}
          >
            <TouchableOpacity style={styles.showMoreButton}>
              <ThemedText style={styles.showMoreText}>
                See all +20 Photos
              </ThemedText>
            </TouchableOpacity>
          </LinearGradient>
        </View>

        <View>
          <ThemedText type="subtitle" style={styles.subtitle}>
            Reviews
          </ThemedText>
          <ThemedText>4.5(100 reviews)</ThemedText>
        </View>

        {displayedComments.map((comment, index) => (
          <MemoizedCommentCard key={index} comment={comment} />
        ))}

        {remainingCommentsCount > 0 && (
          <View style={styles.showMoreContainer}>
            <LinearGradient
              colors={Colors[ColorScheme ?? "light"].packageButton}
              style={styles.showMoreTextWrapper}
            >
              <TouchableOpacity
                onPress={toggleComments}
                style={styles.showMoreButton}
              >
                <ThemedText style={styles.showMoreText}>
                  {showAllComments
                    ? `See fewer comments`
                    : `See ${remainingCommentsCount} more comment${
                        remainingCommentsCount > 1 ? "s" : ""
                      }`}
                </ThemedText>
              </TouchableOpacity>
            </LinearGradient>
          </View>
        )}

        {showAllComments &&
          remainingComments.map((comment, index) => (
            <MemoizedCommentCard key={index} comment={comment} />
          ))}

        <LinearGradient
          colors={Colors[ColorScheme ?? "light"].socialLoginBG}
          style={[styles.bottomContianer]}
        >
          <View
            style={[
              styles.subbottomContianer,
              { borderColor: Colors[ColorScheme ?? "light"].inputBorder },
            ]}
          >
            <Text style={styles.price}>
              {selectedPackage.price}
              <Text>/person</Text>
            </Text>
            <View style={styles.button}>
              <CustomButton
                text="Book Now"
                onPress={() => {
                  router.push("/tour-packages/booking/Bookings");
                }}
              />
            </View>
          </View>
        </LinearGradient>
      </ParallaxScrollView>
    </ThemedView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  mainImage: {
    width: "100%",
    height: 400,
    resizeMode: "cover",
  },
  bottomOverlay: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    height: 450, // Adjust based on how much of the bottom you want to cover
    opacity: 0.7,
  },
  overlayIconLeft: {
    position: "absolute",
    top: 20,
    left: 10,
    zIndex: 1,
  },
  overlayIconBottomLeft: {
    position: "absolute",
    bottom: 70,
    left: 10,
    zIndex: 1,
  },
  title: {
    fontSize: 20,
    color: "white",
  },
  overlayIconRight: {
    position: "absolute",
    top: 20,
    right: 10,
    flexDirection: "row",
    gap: 20,
    zIndex: 1,
  },
  overlayIconBottomRight: {
    position: "absolute",
    bottom: 70,
    right: 10,
    flexDirection: "row",
    gap: 20,
    zIndex: 1,
  },
  iconButton: {
    backgroundColor: "white",
    borderRadius: 50,
    padding: 10,
  },
  showMoreContainer: {
    marginVertical: 15,
    alignItems: "flex-start",
  },
  showMoreButton: {
    padding: 10,
    flexDirection: "row",
  },
  showMoreTextWrapper: {
    borderRadius: 5,
    overflow: "hidden",
    flexDirection: "row",
  },
  showMoreText: {
    fontSize: 14,
  },
  bottomContianer: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 10,
    alignItems: "center",
    borderRadius: 10,
  },
  subbottomContianer: {
    borderRadius: 15,
    borderWidth: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 10,
    alignItems: "center",
  },
  price: {
    flex: 1,
    color: "#0FA3E2",
    fontFamily: "Poppins_600SemiBold",
    fontSize: 16,
  },
  button: {
    flex: 1,
  },
  imageContainer: {
    flexDirection: "row",
    gap: 10,
    marginVertical: 20,
  },
  imageColumn: {
    flex: 1,
  },
  image: {
    width: "100%",
    height: 100,
    marginBottom: 10,
    borderRadius: 10,
  },
  imageVertical: {
    width: "100%",
    height: 210,
    borderRadius: 10,
  },
  headerImageContainer: {
    position: "relative",
  },
  headerPhotoButton: {
    backgroundColor: "rgba(82, 82, 82, 0.8)",
    padding: 10,
    borderRadius: 10,
  },
  headerbtnText: {
    color: "#fff",
    fontFamily: "Poppins_500Medium",
    fontSize: 14,
  },
  subtitle: {
    fontSize: 22,
    fontFamily: "Poppins_600SemiBold",
    marginBottom: 0,
  },
});

export default PackageDetails;
