import React from "react";
import { View, StyleSheet } from "react-native";
import { Tabs } from "expo-router";
import SVGImages from "../../assets/images/SVGIcons";
import UserIcon from "../../assets/images/SVGIcons/UserIcon";
import HeartIcon from "../../assets/images/SVGIcons/HeartIcon";
import BookmarkIcon from "../../assets/images/SVGIcons/BookmarkIcon";
import SettingsIcon from "../../assets/images/SVGIcons/SettingsIcon";
import { ThemedView } from "../../components/ThemedView";
import { useColorScheme } from "../../hooks/useColorScheme";
import { Colors } from "../../constants/Colors";
import { LinearGradient } from "expo-linear-gradient";

export default function TabLayout() {
  const Colorscheme = useColorScheme();
  return (
    <ThemedView style={styles.container}>
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: "blue",
          tabBarShowLabel: false,
          tabBarStyle: [styles.tabBar],
          tabBarBackground: () => (
            <LinearGradient
              colors={Colors[Colorscheme ?? "light"].socialLoginBG}
              start={{ x: 0.5, y: 0 }}
              end={{ x: 0.5, y: 1 }}
              style={styles.tabBarBg}
            />
          ),
        }}
      >
        <Tabs.Screen
          name="Profile"
          options={{
            title: "Profil",
            tabBarIcon: ({ color, focused }) => (
              <UserIcon color={color} focused={focused} />
            ),
            headerShown: false,
          }}
        />
        <Tabs.Screen
          name="Wishlist"
          options={{
            title: "Sevimlilar",
            tabBarIcon: ({ color, focused }) => (
              <HeartIcon color={color} focused={focused} />
            ),
          }}
        />
        <Tabs.Screen
          name="Home"
          options={{
            title: "Bosh sahifa",
            tabBarIcon: ({ color }) => <SVGImages.HomeIcon color={color} />,
          }}
        />
        <Tabs.Screen
          name="Bookings"
          options={{
            title: "Buyurtmalar",
            tabBarIcon: ({ color, focused }) => (
              <BookmarkIcon color={color} focused={focused} />
            ),
          }}
        />
        <Tabs.Screen
          name="Settings"
          options={{
            title: "Sozlamalar",
            tabBarIcon: ({ color, focused }) => (
              <SettingsIcon color={color} focused={focused} />
            ),
          }}
        />
        <Tabs.Screen
          name="SearchPage"
          options={{
            href: null,
          }}
        />
        <Tabs.Screen
          name="tour-packages/[id]"
          options={{
            href: null,
            tabBarStyle: {
              display: "none",
            },
          }}
        />
        <Tabs.Screen
          name="tour-packages/booking/Bookings"
          options={{
            href: null,
          }}
        />
      </Tabs>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingBottom: 10,
  },
  tabBar: {
    paddingVertical: 10,
    paddingBottom: 15,
    paddingHorizontal: 15,
    marginHorizontal: 15,
    marginBottom: 10,
    borderRadius: 50,
    height: 85,
    flexDirection: "row",
    justifyContent: "center",
    borderTopColor: "transparent",
  },
  tabBarBg: {
    paddingVertical: 10,
    paddingBottom: 25,
    height: 90,
    marginBottom: 10,
    borderRadius: 50,
    flexDirection: "row",
    justifyContent: "center",
    borderTopColor: "transparent",
  },
});
