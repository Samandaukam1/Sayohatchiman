import { StyleSheet, Text, View } from "react-native";
import React from "react";
import { ThemedText } from "../../components/ThemedText";
import { ThemedView } from "../../components/ThemedView";

const Bookings = () => {
  return (
    <ThemedView style={styles.container}>
      <ThemedText style={styles.heading}>Mening Buyurtmalarim</ThemedText>
      <View style={styles.messageContainer}>
        <ThemedText style={styles.message}>
          Sahifa hozircha qurilmoqda. Yangiliklardan xabardor bo‘lib turing.
        </ThemedText>
        <ThemedText style={styles.quote}>"Eng yaxshisi hali oldinda."</ThemedText>
      </View>
    </ThemedView>
  );
};

export default Bookings;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  heading: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
    marginTop: 20,
  },
  messageContainer: {
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 20,
  },
  message: {
    fontSize: 18,
    fontStyle: "italic",
    textAlign: "center",
    marginBottom: 20,
  },
  quote: {
    fontSize: 16,
    fontStyle: "italic",
    textAlign: "center",
    marginTop: 10,
  },
});
