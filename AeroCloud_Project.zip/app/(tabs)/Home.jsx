import { ScrollView, StyleSheet, Text, View } from "react-native";
import React from "react";
import HomeHeader from "../../components/HomeComponents/HomeHeader";
import HomePlaces from "../../components/HomeComponents/HomePlaces";
import HomePackages from "../../components/HomeComponents/HomePackages";
import HomeCategory from "../../components/HomeComponents/HomeCategory";
import HomeSearch from "../../components/HomeComponents/HomeSearch";
import { ThemedView } from "../../components/ThemedView";

const Home = () => {
  return (
    <ThemedView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <HomeHeader />
        <HomeSearch />
        <HomeCategory />
        <HomePlaces />
        <HomePackages />
      </ScrollView>
    </ThemedView>
  );
};

export default Home;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    paddingTop: 40,
  },
});
