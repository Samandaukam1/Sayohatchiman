import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  TextInput,
} from "react-native";
import { FontAwesome6 } from "@expo/vector-icons";
import { router } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { useColorScheme } from "../../hooks/useColorScheme";
import { Colors } from "../../constants/Colors";
import { ThemedView } from "../../components/ThemedView";
import { ThemedText } from "../../components/ThemedText";
import HomePlaces from "../../components/HomeComponents/HomePlaces";
import SearchRelatedProduct from "../../components/UI/SearchRelatedProduct";

const SearchPage = ({ navigation }) => {
  const colorScheme = useColorScheme();
  const [searchQuery, setSearchQuery] = useState("");
  const [recentSearches, setRecentSearches] = useState([]);

  const handleSearchSubmit = () => {
    if (searchQuery.trim() !== "") {
      setRecentSearches((prevSearches) => [
        searchQuery,
        ...prevSearches.slice(0, 4),
      ]);
      setSearchQuery(""); // Reset the search query input
    }
  };

  const handleLocationPress = () => {
    navigation.navigate("MapScreen");
  };

  const handleRecentSearchPress = (search) => {
    setSearchQuery(search);
  };

  const handleDeleteRecentSearch = (search) => {
    setRecentSearches((prevSearches) =>
      prevSearches.filter((item) => item !== search)
    );
  };

  const handleClearRecentSearches = () => {
    setRecentSearches([]);
  };

  return (
    <ThemedView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.push("Home")}>
          <FontAwesome6
            name="arrow-left-long"
            size={20}
            color={Colors[colorScheme ?? "light"].text}
          />
        </TouchableOpacity>
        <LinearGradient
          colors={Colors[colorScheme ?? "light"].socialLoginBG}
          style={[
            styles.searchBarContainer,
            {
              borderColor: Colors[colorScheme ?? "light"].inputBorder,
              borderRadius: 10,
            },
          ]}
          start={{ x: 0.5, y: 0 }}
          end={{ x: 0.5, y: 1 }}
        >
          <TouchableOpacity
            onPress={handleSearchSubmit}
            style={styles.searchIconContainer}
          >
            <FontAwesome6 name="magnifying-glass" color="grey" size={16} />
          </TouchableOpacity>
          <TextInput
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="Qayerga borishni xohlaysiz?"
            placeholderTextColor="grey"
            style={[
              styles.searchInput,
              { color: Colors[colorScheme ?? "light"].text },
            ]}
            onSubmitEditing={handleSearchSubmit}
          />
        </LinearGradient>
      </View>

      <TouchableOpacity
        style={styles.locationContainer}
        onPress={handleLocationPress}
      >
        <View style={styles.locationTextContainer}>
          <LinearGradient
            colors={Colors[colorScheme ?? "light"].socialLoginBG}
            style={[
              styles.locationIcon,
              {
                borderColor: Colors[colorScheme ?? "light"].inputBorder,
                borderRadius: 50,
              },
            ]}
            start={{ x: 0.5, y: 0 }}
            end={{ x: 0.5, y: 1 }}
          >
            <TouchableOpacity>
              <FontAwesome6 name="location-dot" size={18} color="#0071C3" />
            </TouchableOpacity>
          </LinearGradient>
          <View>
            <ThemedText style={styles.locationText}>
              Yaqin atrofdagi joylarni qidiring
            </ThemedText>
            <ThemedText style={styles.currentlocationText}>
              Joriy joylashuv - AQSh
            </ThemedText>
          </View>
        </View>
      </TouchableOpacity>

      <View style={styles.recentSearchesContainer}>
        <View style={styles.recentSearchHeader}>
          <ThemedText style={styles.relatedPlaces}>So‘nggi qidiruvlar</ThemedText>
          <TouchableOpacity onPress={handleClearRecentSearches}>
            <FontAwesome6 name="trash-alt" size={20} />
          </TouchableOpacity>
        </View>
        {recentSearches.map((search, index) => (
          <View key={index} style={styles.previousSearchItem}>
            <TouchableOpacity
              onPress={() => handleRecentSearchPress(search)}
              style={styles.searchItem}
            >
              <FontAwesome6
                name="clock"
                size={20}
                color={Colors[colorScheme ?? "light"].text}
              />
              <ThemedText>{search}</ThemedText>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => handleDeleteRecentSearch(search)}>
              <FontAwesome6
                name="xmark"
                size={20}
                color={Colors[colorScheme ?? "light"].text}
              />
            </TouchableOpacity>
          </View>
        ))}
        <SearchRelatedProduct />
      </View>
    </ThemedView>
  );
};

export default SearchPage;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 20,
    marginTop: 30,
    gap: 20,
  },
  searchBarContainer: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 5,
    paddingHorizontal: 15,
    flex: 1,
    height: 50,
    marginRight: 10,
    borderWidth: 1,
    borderRadius: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
  },
  searchIconContainer: {
    marginRight: 10,
  },
  locationContainer: {
    borderRadius: 10,
    marginBottom: 20,
  },
  locationTextContainer: {
    flexDirection: "row",
    alignItems: "center",
    padding: 10,
    borderRadius: 10,
    backgroundColor: Colors.primary,
    gap: 10,
  },
  locationText: {
    fontFamily: "Poppins_700Bold",
  },
  currentlocationText: {
    fontSize: 12,
    color: "#ccc",
  },
  recentSearchesContainer: {
    flex: 1,
  },
  recentSearchHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  relatedPlaces: {
    fontSize: 18,
    fontWeight: "bold",
  },
  previousSearchItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  searchItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  locationIcon: {
    width: 50,
    height: 50,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 50,
    borderWidth: 1,
  },
});
