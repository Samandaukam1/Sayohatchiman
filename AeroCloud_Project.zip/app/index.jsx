import React, { memo, useCallback, useMemo, useState, useRef } from "react";
import {
  StyleSheet,
  View,
  Image,
  FlatList,
  Dimensions,
  TouchableOpacity,
} from "react-native";
import { ThemedView } from "../components/ThemedView";
import { ThemedText } from "../components/ThemedText";
import { onboardingData } from "../helpers/OnboardingData";
import CustomButton from "../components/CustomButton/CustomButton";
import { useColorScheme } from "../hooks/useColorScheme";
import { Colors } from "../constants/Colors";
import { AntDesign } from "@expo/vector-icons";
import { router } from "expo-router";

const { width, height } = Dimensions.get("window");

const OnboardingItem = memo(
  ({ item, themeColors, onNextPress, currentIndex, totalSlides }) => (
    <View style={[styles.itemContainer, { width }]}>
      <Image source={item.image} style={styles.image} resizeMode="contain" />
      <View
        style={[
          styles.itemBox,
          { backgroundColor: themeColors.onboardingBoxBg },
        ]}
      >
        <ThemedText type="title" style={styles.title}>
          {item.heading}
        </ThemedText>
        <ThemedText style={styles.description}>{item.description}</ThemedText>
        <CustomButton
          text={currentIndex === totalSlides - 1 ? "Boshlash" : "Keyingi"}
          onPress={onNextPress}
        />
      </View>
    </View>
  )
);

const Pagination = ({ data, currentIndex, themeColors }) => (
  <View style={styles.paginationContainer}>
    {data.map((_, index) => (
      <View
        key={index}
        style={[
          styles.paginationDot,
          {
            backgroundColor:
              index === currentIndex ? "#0071C3" : themeColors.onboardingBoxBg,
          },
        ]}
      />
    ))}
  </View>
);

const Onboarding = () => {
  const colorScheme = useColorScheme();
  const themeColors = Colors[colorScheme ?? "light"];
  const [currentIndex, setCurrentIndex] = useState(0);
  const flatListRef = useRef(null);

  const handleSkip = useCallback(() => {
    router.push("/Login");
  }, []);

  const handleNext = useCallback(() => {
    if (currentIndex < onboardingData.length - 1) {
      flatListRef.current?.scrollToIndex({
        index: currentIndex + 1,
        animated: true,
      });
      setCurrentIndex(currentIndex + 1);
    } else {
      router.push("/Login"); // Oxirgi slayddan keyin Login sahifasiga o'tish
    }
  }, [currentIndex]);

  const renderItem = useCallback(
    ({ item }) => (
      <OnboardingItem
        item={item}
        themeColors={themeColors}
        onNextPress={handleNext}
        currentIndex={currentIndex}
        totalSlides={onboardingData.length}
      />
    ),
    [themeColors, handleNext, currentIndex]
  );

  const keyExtractor = useCallback(
    (item, index) => `${item.heading}-${index}`,
    []
  );

  const onViewableItemsChanged = useCallback(({ viewableItems }) => {
    if (viewableItems.length > 0) {
      setCurrentIndex(viewableItems[0].index);
    }
  }, []);

  const viewabilityConfig = useMemo(
    () => ({
      itemVisiblePercentThreshold: 50,
    }),
    []
  );

  const memoizedFlatList = useMemo(
    () => (
      <FlatList
        ref={flatListRef}
        data={onboardingData}
        renderItem={renderItem}
        keyExtractor={keyExtractor}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        bounces={false}
        onViewableItemsChanged={onViewableItemsChanged}
        viewabilityConfig={viewabilityConfig}
        getItemLayout={(data, index) => ({
          length: width,
          offset: width * index,
          index,
        })}
      />
    ),
    [renderItem, keyExtractor, onViewableItemsChanged, viewabilityConfig]
  );

  return (
    <ThemedView style={styles.container}>
      <TouchableOpacity style={styles.skipButton} onPress={handleSkip}>
        <ThemedText style={styles.skipText}>O‘tish</ThemedText>
        <AntDesign name="right" size={14} color={themeColors.text} />
      </TouchableOpacity>
      {memoizedFlatList}
      <Pagination
        data={onboardingData}
        currentIndex={currentIndex}
        themeColors={themeColors}
      />
    </ThemedView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 60,
    paddingBottom: 20,
  },
  itemContainer: {
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 20,
  },
  image: {
    height: 350,
    width: "100%",
    marginBottom: 20,
  },
  itemBox: {
    padding: 30,
    borderRadius: 20,
    width: "100%",
  },
  title: {
    fontSize: 24,
    marginBottom: 10,
    lineHeight: 30,
  },
  description: {
    fontSize: 14,
    lineHeight: 21,
    marginBottom: 20,
  },
  skipButton: {
    alignSelf: "flex-end",
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
    marginRight: 15,
  },
  skipText: {
    fontSize: 14,
  },
  paginationContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 20,
  },
  paginationDot: {
    width: 21,
    height: 6,
    borderRadius: 70,
    marginHorizontal: 5,
  },
});

export default Onboarding;
