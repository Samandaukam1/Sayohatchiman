import { Image, StyleSheet, Text, View, ScrollView } from "react-native";
import React from "react";
import SuccessImage from "../../assets/images/Images/Onboarding/SuccessImage.png";
import SuccessDark from "../../assets/images/Images/Onboarding/SuccessDark.png";
import CustomButton from "../../components/CustomButton/CustomButton";
import { router } from "expo-router";
import { ThemedView } from "../../components/ThemedView";
import { ThemedText } from "../../components/ThemedText";
import { useColorScheme } from "../../hooks/useColorScheme";

const SuccessPage = () => {
  const ColorScheme = useColorScheme();
  return (
    <ThemedView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Image
          source={ColorScheme === "light" ? SuccessImage : SuccessDark}
          style={styles.image}
        />
        <ThemedText type="title" style={styles.heading}>
          Hisob muvaffaqiyatli yaratildi
        </ThemedText>
        <ThemedText style={styles.description}>
          Tizimga xush kelibsiz! Endi siz platformamizdagi barcha funksiyalardan bemalol foydalanishingiz mumkin. Davom etish uchun “Tugatish” tugmasini bosing.
        </ThemedText>
      </ScrollView>
      <CustomButton text="Tugatish" onPress={() => router.push("Home")} />
    </ThemedView>
  );
};

export default SuccessPage;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingVertical: 20,
    justifyContent: "center",
  },
  scrollContent: {
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
  },
  heading: {
    textAlign: "center",
    fontSize: 30,
    marginTop: 30,
  },
  description: {
    fontSize: 14,
    textAlign: "center",
    paddingVertical: 20,
    lineHeight: 20,
    letterSpacing: 0.5,
  },
  image: {
    width: "100%",
    height: 350,
    resizeMode: "contain",
    marginTop: 30,
  },
});
