import {
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";
import React, { useState } from "react";
import { FontAwesome6 } from "@expo/vector-icons";
import InputComponent from "../../components/InputComponent/InputComponent";
import CustomButton from "../../components/CustomButton/CustomButton";
import { router } from "expo-router";
import { Colors } from "../../constants/Colors";
import { useColorScheme } from "../../hooks/useColorScheme";
import { ThemedView } from "../../components/ThemedView";
import { ThemedText } from "../../components/ThemedText";

const CreatePassword = () => {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const colorScheme = useColorScheme();

  const goBack = () => {
    router.back();
  };

  return (
    <ThemedView style={styles.container}>
      <ScrollView>
        <TouchableOpacity onPress={goBack} style={styles.backButton}>
          <FontAwesome6
            name="arrow-left"
            size={24}
            color={Colors[colorScheme ?? "light"].text}
          />
        </TouchableOpacity>
        <ThemedText style={styles.subHeading}>Parolni unutdingizmi?</ThemedText>
        <ThemedText type="title" style={styles.heading}>
          Yangi parol yarating
        </ThemedText>
        <InputComponent
          label="Yangi parol"
          placeholder="Parolingizni kiriting"
          value={password}
          onChangeText={setPassword}
        />
        <InputComponent
          label="Parolni tasdiqlang"
          placeholder="Parolingizni qayta kiriting"
          value={confirmPassword}
          onChangeText={setConfirmPassword}
        />
      </ScrollView>
      <CustomButton text="Yuborish" onPress={() => router.push("Login")} />
    </ThemedView>
  );
};

export default CreatePassword;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    paddingTop: 50,
  },
  heading: {
    fontSize: 30,
    marginBottom: 10,
  },
  subHeading: {
    color: "#474747",
    fontSize: 16,
    marginBottom: 10,
    marginTop: 10,
  },
  backButton: {
    marginBottom: 15,
  },
});
