import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Dimensions,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import CustomButton from "../../components/CustomButton/CustomButton";
import SVGImages from "../../assets/images/SVGIcons";
import InputComponent from "../../components/InputComponent/InputComponent";
import { router } from "expo-router";
import { ThemedView } from "../../components/ThemedView";
import { ThemedText } from "../../components/ThemedText";
import { Colors } from "../../constants/Colors";
import { useColorScheme } from "../../hooks/useColorScheme";
import MyCheckbox from "../../components/MyCheckbox/MyCheckbox";

const { width } = Dimensions.get("window");

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [toggleCheckBox, setToggleCheckBox] = useState(false);
  const colorScheme = useColorScheme();
  const themeColors = Colors[colorScheme ?? "light"];

  return (
    <ThemedView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollViewContent}>
        <SVGImages.Logo style={styles.logo} />

        <View style={styles.inputContainer}>
          <InputComponent
            label="Email"
            placeholder="ali.nurmatov@gmail.com"
            value={email}
            onChangeText={setEmail}
          />

          <InputComponent
            label="Parol"
            placeholder="*********"
            value={password}
            onChangeText={setPassword}
            secureTextEntry={true}
          />

          <View style={styles.rememberMeContainer}>
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <MyCheckbox />
              <ThemedText style={styles.rememberMeText}>Eslab qolish</ThemedText>
            </View>

            <TouchableOpacity onPress={() => router.push("ForgotPassword")}>
              <Text style={styles.forgotPasswordText}>Parolni unutdingizmi?</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.signInButtons}>
            <TouchableOpacity style={styles.signInBtnWrapper}>
              <LinearGradient
                colors={themeColors.socialLoginBG}
                style={styles.signInBtn}
              >
                <SVGImages.GoogleIcon />
                <ThemedText style={styles.signInBtnText}>Google orqali</ThemedText>
              </LinearGradient>
              <View style={[styles.border, { borderColor: "#000" }]} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.signInBtnWrapper}>
              <LinearGradient
                colors={themeColors.socialLoginBG}
                style={styles.signInBtn}
              >
                <SVGImages.FacebookIcon />
                <ThemedText style={styles.signInBtnText}>Facebook orqali</ThemedText>
              </LinearGradient>
              <View style={[styles.border, { borderColor: "#000" }]} />
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>

      <View style={styles.bottomButtons}>
        <CustomButton
          text="Ro‘yxatdan o‘tish"
          onPress={() => router.push("CreateAccount")}
        />
        <View style={{ marginVertical: 10 }} />
        <CustomButton text="Kirish" onPress={() => router.push("Home")} />
      </View>
    </ThemedView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 30,
  },
  scrollViewContent: {
    flexGrow: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  logo: {
    marginBottom: 20,
  },
  rememberMeContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 40,
    justifyContent: "space-between",
  },
  rememberMeText: {
    marginLeft: 10,
    fontSize: 16,
  },
  forgotPasswordText: {
    fontSize: 16,
    color: "#0FA3E2",
    textAlign: "right",
    alignSelf: "flex-end",
  },
  inputContainer: {
    marginTop: 20,
    width: "100%",
  },
  signInButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 20,
    width: "100%",
  },
  signInBtnWrapper: {
    width: "48%",
    borderRadius: 20,
    overflow: "hidden",
    position: "relative",
  },
  signInBtn: {
    flexDirection: "row",
    width: "100%",
    padding: 15,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  signInBtnText: {
    marginLeft: 10,
    fontSize: 16,
  },
  border: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1,
    borderRadius: 20,
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  bottomButtons: {
    marginBottom: 20,
  },
});

export default Login;
