import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import React, { useState } from "react";
import CreateName from "../../components/CreateAccount/CreateName";
import CustomButton from "../../components/CustomButton/CustomButton";
import CreateEmail from "../../components/CreateAccount/CreateEmail";
import CreatePassword from "../../components/CreateAccount/CreatePassword";
import { FontAwesome6 } from "@expo/vector-icons";
import { router } from "expo-router";
import { Colors } from "../../constants/Colors";
import { useColorScheme } from "../../hooks/useColorScheme";
import { ThemedView } from "../../components/ThemedView";
import { ThemedText } from "../../components/ThemedText";

const CreateAccount = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const colorScheme = useColorScheme();

  const goBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    } else {
      router.back();
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return <CreateName />;
      case 2:
        return <CreateEmail />;
      case 3:
        return <CreatePassword />;
      default:
        return <CreateName />;
    }
  };

  const handleNextPress = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    } else {
      // Yakuniy bosqich - yuborish
      router.push("SuccessPage");
    }
  };

  const getButtonText = () => {
    return currentStep === 3 ? "Yuborish" : "Keyingisi";
  };

  const getProgressStyle = (step) => {
    return {
      ...styles.pageProgress,
      backgroundColor:
        currentStep >= step ? "rgba(0, 137, 221, 1)" : "rgba(0, 137, 221, 0.1)",
    };
  };

  return (
    <ThemedView style={styles.container}>
      <TouchableOpacity onPress={goBack} style={styles.backButton}>
        <FontAwesome6
          name="arrow-left"
          size={24}
          color={Colors[colorScheme ?? "light"].text}
        />
      </TouchableOpacity>
      <ScrollView showsVerticalScrollIndicator={false}>
        {renderStep()}
      </ScrollView>
      <CustomButton text={getButtonText()} onPress={handleNextPress} />
      <View style={styles.pageProgressContainer}>
        <View style={getProgressStyle(1)}></View>
        <View style={getProgressStyle(2)}></View>
        <View style={getProgressStyle(3)}></View>
      </View>
    </ThemedView>
  );
};

export default CreateAccount;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    paddingTop: 50,
  },
  backButton: {
    marginBottom: 15,
    marginTop: 20,
  },
  pageProgressContainer: {
    marginTop: 15,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  pageProgress: {
    marginVertical: 10,
    width: 90,
    height: 7,
    borderRadius: 50,
  },
});
