import {
  ScrollView,
  StyleSheet,
  TouchableOpacity,
} from "react-native";
import React, { useState } from "react";
import { FontAwesome6 } from "@expo/vector-icons";
import InputComponent from "../../components/InputComponent/InputComponent";
import CustomButton from "../../components/CustomButton/CustomButton";
import { router } from "expo-router";
import { Colors } from "../../constants/Colors";
import { useColorScheme } from "../../hooks/useColorScheme";
import { ThemedView } from "../../components/ThemedView";
import { ThemedText } from "../../components/ThemedText";

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const colorScheme = useColorScheme();

  const goBack = () => {
    router.back();
  };

  return (
    <ThemedView style={styles.container}>
      <ScrollView>
        <TouchableOpacity onPress={goBack} style={styles.backButton}>
          <FontAwesome6
            name="arrow-left"
            size={24}
            color={Colors[colorScheme ?? "light"].text}
          />
        </TouchableOpacity>
        <ThemedText style={styles.subHeading}>Email manzilingizni kiriting</ThemedText>
        <ThemedText type="title" style={styles.heading}>
          Parolni unutdingizmi?
        </ThemedText>
        <InputComponent
          label="Email"
          placeholder="misol: asliddinn56@example.com"
          value={email}
          onChangeText={setEmail}
        />
      </ScrollView>
      <CustomButton
        text="Davom etish"
        onPress={() => router.push("CreatePassword")}
      />
    </ThemedView>
  );
};

export default ForgotPassword;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    paddingTop: 50,
  },
  heading: {
    fontSize: 30,
    marginBottom: 10,
  },
  subHeading: {
    fontSize: 16,
    marginBottom: 10,
    marginTop: 10,
    color: "#474747",
  },
  backButton: {
    marginBottom: 15,
  },
});
