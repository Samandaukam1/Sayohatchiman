export const onboardingData = [
  {
    image: require("../assets/images/Images/Onboarding/Onboarding1.webp"),
    heading: "Get ready for the next trip",
    description:
      "Find thousands of tourist destinations ready for you to visit",
  },
  {
    image: require("../assets/images/Images/Onboarding/Onboarding2.webp"),
    heading: "Visit the Places attractions",
    description:
      "Find thousands of tourist destinations ready for you to visit",
  },
  {
    image: require("../assets/images/Images/Onboarding/Onboarding3.webp"),
    heading: "Make the moment Memorable",
    description:
      "Find thousands of tourist destinations ready for you to visit",
  },
];
